package dev.remotecontrol;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;

/**
 * Version-sensitive calls live here. If the build fails on a Minecraft API name,
 * the fix is almost certainly in this file.
 */
public final class Compat {
    private Compat() {}

    /** Same steps as the pause menu's "Save and Quit" / "Disconnect" button. */
    public static void leave(MinecraftClient c) {
        if (c.world == null) return;
        boolean local = c.isInSingleplayer();
        ServerInfo si = c.getCurrentServerEntry();
        c.world.disconnect(Text.literal("Quitting"));
        if (local) c.disconnectWithSavingScreen();
        else c.disconnectWithProgressScreen();
        TitleScreen title = new TitleScreen();
        c.setScreen(local ? title : new MultiplayerScreen(title));
    }
}
