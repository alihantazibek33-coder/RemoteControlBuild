package dev.remotecontrol;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.GameOptionsScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.MathHelper;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/** Everything the controlled client does on behalf of the controller. */
public final class Actions {
    private Actions() {}

    /** key name -> ticks left (-1 = until released). */
    private static final Map<String, Integer> HELD = new LinkedHashMap<>();

    public static KeyBinding key(MinecraftClient c, String n) {
        GameOptions o = c.options;
        return switch (n) {
            case "forward" -> o.forwardKey;
            case "back" -> o.backKey;
            case "left" -> o.leftKey;
            case "right" -> o.rightKey;
            case "jump" -> o.jumpKey;
            case "sneak" -> o.sneakKey;
            case "sprint" -> o.sprintKey;
            case "attack" -> o.attackKey;
            case "use" -> o.useKey;
            case "drop" -> o.dropKey;
            case "swap" -> o.swapHandsKey;
            case "pick" -> o.pickItemKey;
            case "inventory" -> o.inventoryKey;
            case "playerlist" -> o.playerListKey;
            default -> null;
        };
    }

    public static void run(MinecraftClient c, JsonObject o) {
        String a = Remote.str(o, "a");
        ClientPlayerEntity p = c.player;
        switch (a) {
            case "say" -> {
                if (p == null) return;
                String text = Remote.str(o, "text").trim();
                if (text.isEmpty()) return;
                if (text.length() > 256) text = text.substring(0, 256);
                if (text.startsWith("/")) p.networkHandler.sendChatCommand(text.substring(1));
                else p.networkHandler.sendChatMessage(text);
            }
            case "leave" -> Compat.leave(c);
            case "toggle" -> {
                String k = Remote.str(o, "key");
                if (key(c, k) == null) return;
                if (HELD.containsKey(k)) { HELD.remove(k); key(c, k).setPressed(false); }
                else HELD.put(k, -1);
            }
            case "tap" -> hold(c, Remote.str(o, "key"), Math.max(1, Math.min(20, num(o, "ticks", 3))));
            case "hold" -> hold(c, Remote.str(o, "key"), Math.max(1, Math.min(1200, num(o, "ticks", 20))));
            case "release" -> {
                String k = Remote.str(o, "key");
                HELD.remove(k);
                KeyBinding kb = key(c, k);
                if (kb != null) kb.setPressed(false);
            }
            case "releaseAll" -> releaseAll(c);
            case "look" -> {
                if (p == null) return;
                p.setYaw(p.getYaw() + (float) num(o, "dyaw", 0));
                p.setPitch(MathHelper.clamp(p.getPitch() + (float) num(o, "dpitch", 0), -90f, 90f));
            }
            case "slot" -> {
                if (p == null) return;
                int n = num(o, "n", 0);
                if (n >= 0 && n <= 8) p.getInventory().setSelectedSlot(n);
            }
            default -> { }
        }
    }

    private static int num(JsonObject o, String k, int def) {
        try { return o.has(k) ? o.get(k).getAsInt() : def; } catch (Exception e) { return def; }
    }

    private static void hold(MinecraftClient c, String k, int ticks) {
        if (key(c, k) != null) HELD.put(k, ticks);
    }

    public static void tickHeld(MinecraftClient c) {
        Iterator<Map.Entry<String, Integer>> it = HELD.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Integer> e = it.next();
            KeyBinding kb = key(c, e.getKey());
            if (kb == null) { it.remove(); continue; }
            kb.setPressed(true);
            int left = e.getValue();
            if (left > 0) {
                if (left == 1) { kb.setPressed(false); it.remove(); }
                else e.setValue(left - 1);
            }
        }
    }

    public static void releaseAll(MinecraftClient c) {
        for (String k : HELD.keySet()) {
            KeyBinding kb = key(c, k);
            if (kb != null) kb.setPressed(false);
        }
        HELD.clear();
    }

    // ---------------- status snapshot ----------------
    public static JsonObject status(MinecraftClient c) {
        JsonObject o = new JsonObject();
        ClientPlayerEntity p = c.player;
        Screen s = c.currentScreen;

        if (c.world != null && p != null) {
            if (c.isInSingleplayer()) {
                o.addProperty("w", "sp");
                String name = "?";
                try { name = c.getServer().getSaveProperties().getLevelName(); } catch (Exception ignored) {}
                o.addProperty("d", name);
            } else {
                o.addProperty("w", "mp");
                ServerInfo si = c.getCurrentServerEntry();
                o.addProperty("d", si != null ? si.address : "?");
            }
            o.addProperty("hp", p.getHealth());
            o.addProperty("food", p.getHungerManager().getFoodLevel());
            o.addProperty("x", Math.round(p.getX() * 10) / 10.0);
            o.addProperty("y", Math.round(p.getY() * 10) / 10.0);
            o.addProperty("z", Math.round(p.getZ() * 10) / 10.0);
            o.addProperty("dim", c.world.getRegistryKey().getValue().toString());
            o.addProperty("slot", p.getInventory().getSelectedSlot());

            JsonArray inv = new JsonArray();
            for (int i = 0; i < 36; i++) addStack(inv, i, p.getInventory().getStack(i));
            EquipmentSlot[] arm = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (int i = 0; i < 4; i++) addStack(inv, 100 + i, p.getEquippedStack(arm[i]));
            addStack(inv, 150, p.getOffHandStack());
            o.add("inv", inv);
        } else if (s instanceof TitleScreen) o.addProperty("w", "title");
        else if (s instanceof OptionsScreen || s instanceof GameOptionsScreen) o.addProperty("w", "options");
        else if (s instanceof SelectWorldScreen) o.addProperty("w", "worlds");
        else if (s instanceof MultiplayerScreen) o.addProperty("w", "servers");
        else o.addProperty("w", "other");

        if (s != null) o.addProperty("scr", s.getTitle().getString());

        JsonArray held = new JsonArray();
        for (String k : HELD.keySet()) held.add(k);
        o.add("held", held);
        return o;
    }

    private static void addStack(JsonArray arr, int slot, ItemStack st) {
        if (st == null || st.isEmpty()) return;
        JsonObject e = new JsonObject();
        e.addProperty("s", slot);
        e.addProperty("id", Registries.ITEM.getId(st.getItem()).toString());
        e.addProperty("c", st.getCount());
        e.addProperty("n", st.getName().getString());
        arr.add(e);
    }
}
