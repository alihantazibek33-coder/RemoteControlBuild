package dev.remotecontrol;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Line-delimited JSON connection to the relay (auto-reconnect). */
public final class RelayClient {
    public volatile boolean connected;
    public volatile String lastError = "";
    public volatile List<String> online = List.of(); // lowercase names
    private volatile BufferedWriter out;

    public void start() {
        Thread t = new Thread(this::loop, "RC-Relay");
        t.setDaemon(true);
        t.start();
    }

    private void loop() {
        while (true) {
            try { connectAndRead(); } catch (Exception e) { lastError = String.valueOf(e.getMessage()); }
            connected = false;
            out = null;
            try { Thread.sleep(5000); } catch (InterruptedException ignored) { return; }
        }
    }

    private void connectAndRead() throws IOException {
        Config c = Config.get();
        String name = MinecraftClient.getInstance().getSession().getUsername();
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(c.host(), c.port()), 5000);
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            // Minecraft handshake first: playit "Minecraft Java" tunnels route by hostname. The relay discards it.
            OutputStream raw = s.getOutputStream();
            ByteArrayOutputStream body = new ByteArrayOutputStream();
            writeVarInt(body, 0);
            writeVarInt(body, 774);
            byte[] hb = c.host().getBytes(StandardCharsets.UTF_8);
            writeVarInt(body, hb.length);
            body.write(hb);
            body.write((c.port() >> 8) & 0xFF);
            body.write(c.port() & 0xFF);
            writeVarInt(body, 2);
            writeVarInt(raw, body.size());
            raw.write(body.toByteArray());
            raw.flush();
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
            JsonObject hello = new JsonObject();
            hello.addProperty("op", "hello");
            hello.addProperty("name", name);
            hello.addProperty("secret", c.key());
            send(hello);
            String line;
            while ((line = in.readLine()) != null) {
                try {
                    JsonElement e = JsonParser.parseString(line);
                    if (!e.isJsonObject()) continue;
                    JsonObject o = e.getAsJsonObject();
                    String op = o.has("op") ? o.get("op").getAsString() : "";
                    if (op.equals("hello_ok")) { connected = true; lastError = ""; }
                    else if (op.equals("online")) {
                        List<String> l = new ArrayList<>();
                        JsonArray a = o.getAsJsonArray("names");
                        for (JsonElement n : a) l.add(n.getAsString().toLowerCase());
                        online = l;
                    } else Remote.onRelay(o);
                } catch (Exception ignored) {}
            }
        }
    }

    private static void writeVarInt(OutputStream o, int v) throws IOException {
        while ((v & ~0x7F) != 0) { o.write((v & 0x7F) | 0x80); v >>>= 7; }
        o.write(v);
    }

    public void send(JsonObject o) {
        BufferedWriter w = out;
        if (w == null) return;
        synchronized (this) {
            try { w.write(o.toString()); w.write('\n'); w.flush(); } catch (IOException ignored) {}
        }
    }
}
