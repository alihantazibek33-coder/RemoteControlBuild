package dev.remotecontrol;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;

public class RemoteControlMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Config.load();
        Remote.RELAY.start();
        ClientTickEvents.END_CLIENT_TICK.register(Remote::onTick);
        ClientSendMessageEvents.ALLOW_CHAT.register(Remote::onOutgoingChat);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) Remote.forwardChat(message.getString());
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, time) ->
                Remote.forwardChat(message.getString()));
    }
}
