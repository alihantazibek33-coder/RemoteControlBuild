package dev.remotecontrol;

import com.google.gson.JsonObject;
import dev.remotecontrol.ui.MenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Protocol + state. Target side = the player being controlled; controller side = the one controlling. */
public final class Remote {
    public static final RelayClient RELAY = new RelayClient();
    private static final Map<String, Session> SESSIONS = new ConcurrentHashMap<>();

    // ---- target side (client thread only) ----
    public static String controller;
    private static String pendingFrom;
    private static long pendingAt;
    private static boolean pendingShown;
    private static int tick;

    private static final long REQUEST_TIMEOUT_MS = 60_000;

    public static Session session(String name) {
        return SESSIONS.computeIfAbsent(name.toLowerCase(Locale.ROOT), k -> new Session(name));
    }

    // ================= sending helpers =================
    public static JsonObject obj(String a, Object... kv) {
        JsonObject o = new JsonObject();
        o.addProperty("t", "cmd");
        o.addProperty("a", a);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            Object v = kv[i + 1];
            if (v instanceof Number n) o.addProperty((String) kv[i], n);
            else o.addProperty((String) kv[i], String.valueOf(v));
        }
        return o;
    }

    public static void sendTo(String to, JsonObject body) {
        body.addProperty("op", "msg");
        body.addProperty("to", to);
        RELAY.send(body);
    }

    private static void reply(String to, String t, String note) {
        JsonObject o = new JsonObject();
        o.addProperty("t", t);
        o.addProperty("note", note);
        sendTo(to, o);
    }

    // ================= controller side =================
    public static void request(String name) {
        Session s = session(name);
        s.state = Session.REQUESTED;
        s.note = "";
        s.status = null;
        s.log("Рұқсат сұралды...");
        JsonObject o = new JsonObject();
        o.addProperty("t", "req");
        sendTo(name, o);
    }

    public static void cmd(String name, JsonObject o) {
        Session s = session(name);
        if (s.state != Session.GRANTED) { s.log("Рұқсат жоқ"); return; }
        sendTo(name, o);
    }

    public static void endSession(String name) {
        Session s = session(name);
        if (s.state == Session.GRANTED || s.state == Session.REQUESTED) {
            JsonObject o = new JsonObject();
            o.addProperty("t", "stop");
            sendTo(name, o);
        }
        s.state = Session.IDLE;
        s.status = null;
    }

    // ================= inbound (relay thread) =================
    public static void onRelay(JsonObject o) {
        String op = str(o, "op");
        if (op.equals("err")) {
            String r = str(o, "reason");
            RELAY.lastError = r;
            String to = str(o, "to");
            if (r.equals("offline") && !to.isEmpty()) {
                Session s = session(to);
                if (s.state == Session.REQUESTED || s.state == Session.GRANTED) {
                    s.state = Session.REFUSED;
                    s.note = "офлайн (relay-де жоқ)";
                    s.log("Ойыншы офлайн");
                }
            }
            return;
        }
        if (!op.equals("msg")) return;
        String from = str(o, "from");
        String t = str(o, "t");
        MinecraftClient mc = MinecraftClient.getInstance();
        switch (t) {
            case "req" -> mc.execute(() -> onRequest(from));
            case "accepted" -> {
                Session s = session(from);
                s.state = Session.GRANTED;
                s.log("Рұқсат берілді ✔");
            }
            case "denied" -> {
                Session s = session(from);
                s.state = Session.REFUSED;
                s.note = str(o, "note");
                s.log("Бас тартылды " + s.note);
            }
            case "stop" -> {
                Session s = session(from);
                if (s.state != Session.IDLE) s.log("Сессия аяқталды");
                s.state = Session.IDLE;
                mc.execute(() -> { if (from.equalsIgnoreCase(controller)) endControl(false); });
            }
            case "status" -> {
                Session s = session(from);
                s.status = o;
                s.statusAt = System.currentTimeMillis();
            }
            case "chat" -> session(from).log(str(o, "line"));
            case "cmd" -> mc.execute(() -> {
                if (controller != null && controller.equalsIgnoreCase(from)) Actions.run(mc, o);
            });
            default -> { }
        }
    }

    static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    // ================= target side =================
    private static void onRequest(String from) {
        if (controller != null) { reply(from, "denied", "(бос емес: басқарып жатыр)"); return; }
        if (pendingFrom != null && !pendingFrom.equalsIgnoreCase(from)) { reply(from, "denied", "(бос емес: басқа сұрау бар)"); return; }
        pendingFrom = from;
        pendingAt = System.currentTimeMillis();
        pendingShown = false;
    }

    private static void showPending() {
        pendingShown = true;
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.inGameHud.getChatHud().addMessage(Text.literal("§6§lРұқсат алу! §f(" + pendingFrom + ")"));
        mc.inGameHud.getChatHud().addMessage(Text.literal("§a.accept §7/ §c.deny"));
    }

    public static boolean onOutgoingChat(String msg) {
        switch (msg.trim().toLowerCase(Locale.ROOT)) {
            case ".remotecontrol", ".rc" -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                mc.execute(() -> mc.setScreen(new MenuScreen()));
                return false;
            }
            case ".accept" -> {
                if (pendingFrom == null) return false;
                controller = pendingFrom;
                pendingFrom = null;
                tick = 0;
                reply(controller, "accepted", "");
                return false;
            }
            case ".deny" -> {
                if (pendingFrom == null) return false;
                reply(pendingFrom, "denied", "");
                pendingFrom = null;
                return false;
            }
            case ".stop" -> {
                if (controller == null) return false;
                endControl(true);
                return false;
            }
            default -> { return true; }
        }
    }

    private static void endControl(boolean notify) {
        if (controller == null) return;
        if (notify) reply(controller, "stop", "");
        controller = null;
        Actions.releaseAll(MinecraftClient.getInstance());
    }

    public static void forwardChat(String line) {
        if (controller == null || line.isEmpty() || line.startsWith("[RC]")) return;
        JsonObject o = new JsonObject();
        o.addProperty("t", "chat");
        o.addProperty("line", line.length() > 200 ? line.substring(0, 200) : line);
        sendTo(controller, o);
    }

    // ================= per-tick =================
    public static void onTick(MinecraftClient mc) {
        tick++;

        if (tick % 100 == 0) {
            JsonObject w = new JsonObject();
            w.addProperty("op", "who");
            RELAY.send(w);
        }

        if (pendingFrom != null) {
            if (System.currentTimeMillis() - pendingAt > REQUEST_TIMEOUT_MS) {
                reply(pendingFrom, "denied", "(уақыт бітті)");
                pendingFrom = null;
            } else if (!pendingShown && mc.player != null) {
                showPending();
            }
        }

        if (controller != null) {
            Actions.tickHeld(mc);
            if (tick % 10 == 0) {
                JsonObject st = Actions.status(mc);
                st.addProperty("t", "status");
                sendTo(controller, st);
            }
        }
    }

    public static List<String> online() { return RELAY.online; }
}
