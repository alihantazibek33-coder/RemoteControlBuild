package dev.remotecontrol;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** config/remotecontrol.json */
public final class Config {
    // ===== МОДТЫ ЖИНАМАС БҰРЫН ОСЫ ҮШЕУІН ӨЗГЕРТ =====
    public static final String DEFAULT_HOST = "chords-conquest.tun.ply.gg";   // relay IP / домен
    public static final int DEFAULT_PORT = 25565;            // playit Minecraft тунелі: әрқашан 25565
    public static final String DEFAULT_SECRET = "change-me"; // relay-дегі RELAY_SECRET-пен бірдей
    // ====================================================

    // null = жоғарыдағы әдепкіні қолдану. Config файлына қолмен жазудың керегі жоқ.
    public String relayHost;
    public Integer relayPort;
    public String secret;
    public List<String> friends = new ArrayList<>();

    public String host() { return relayHost == null || relayHost.isBlank() ? DEFAULT_HOST : relayHost; }
    public int port() { return relayPort == null ? DEFAULT_PORT : relayPort; }
    public String key() { return secret == null ? DEFAULT_SECRET : secret; }

    private static Config inst = new Config();
    private static final Gson G = new GsonBuilder().setPrettyPrinting().create();

    public static Config get() { return inst; }

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("remotecontrol.json"); }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config c = G.fromJson(Files.readString(p), Config.class);
                if (c != null) {
                    if (c.friends == null) c.friends = new ArrayList<>();
                    inst = c;
                }
            }
            save();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void save() {
        try { Files.writeString(path(), G.toJson(inst)); } catch (Exception ignored) {}
    }

    public static void addFriend(String n) {
        for (String f : inst.friends) if (f.equalsIgnoreCase(n)) return;
        inst.friends.add(n);
        save();
    }

    public static void removeFriend(String n) {
        inst.friends.removeIf(f -> f.equalsIgnoreCase(n));
        save();
    }
}
