package dev.remotecontrol;

import com.google.gson.JsonObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Controller-side view of one controlled player. */
public final class Session {
    public static final int IDLE = 0, REQUESTED = 1, GRANTED = 2, REFUSED = 3;

    public final String name;
    public volatile int state = IDLE;
    public volatile String note = "";
    public volatile JsonObject status;
    public volatile long statusAt;
    private final ArrayDeque<String> log = new ArrayDeque<>();

    public Session(String name) { this.name = name; }

    public synchronized void log(String s) {
        log.addLast(s);
        while (log.size() > 100) log.removeFirst();
    }

    public synchronized List<String> last(int n) {
        List<String> all = new ArrayList<>(log);
        return new ArrayList<>(all.subList(Math.max(0, all.size() - n), all.size()));
    }
}
