package dev.remotecontrol.ui;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.remotecontrol.Remote;
import dev.remotecontrol.Session;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

/** Console + buttons + live status of one controlled player. */
public class ControlScreen extends Screen {
    private final String target;
    private TextFieldWidget input;

    public ControlScreen(String target) {
        super(Text.literal("Control " + target));
        this.target = target;
    }

    private Session s() { return Remote.session(target); }

    private void btn(String label, int x, int y, int w, Runnable r) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> r.run()).dimensions(x, y, w, 20).build());
    }

    private void toggle(String key) { Remote.cmd(target, Remote.obj("toggle", "key", key)); }
    private void tap(String key) { Remote.cmd(target, Remote.obj("tap", "key", key, "ticks", 3)); }

    @Override
    protected void init() {
        int cx = width / 2;
        int rowClose = height - 24, rowLook = height - 46, rowSlots = height - 68,
                rowAct = height - 90, rowMove = height - 112, rowInput = height - 136;

        input = new TextFieldWidget(textRenderer, cx - 180, rowInput, 290, 20, Text.literal("console"));
        input.setMaxLength(256);
        input.setPlaceholder(Text.literal("чат / /команда   (.key jump | .hold forward 40 | .release forward)"));
        addDrawableChild(input);
        btn("Жіберу", cx + 114, rowInput, 66, this::submit);

        int x = cx - 180;
        String[] ml = {"Алға", "Артқа", "Солға", "Оңға", "Еңкею", "Жүгіру"};
        String[] mk = {"forward", "back", "left", "right", "sneak", "sprint"};
        for (int i = 0; i < 6; i++) { String k = mk[i]; btn(ml[i], x + i * 60, rowMove, 58, () -> toggle(k)); }

        String[] al = {"Секіру", "Соққы", "Қолдану", "Тастау", "Қол ауыс."};
        String[] ak = {"jump", "attack", "use", "drop", "swap"};
        for (int i = 0; i < 5; i++) { String k = ak[i]; btn(al[i], x + i * 60, rowAct, 58, () -> tap(k)); }
        btn("Босату", x + 300, rowAct, 60, () -> Remote.cmd(target, Remote.obj("releaseAll")));

        int sx = cx - 108;
        for (int i = 0; i < 9; i++) {
            int n = i;
            btn(String.valueOf(i + 1), sx + i * 24, rowSlots, 22, () -> Remote.cmd(target, Remote.obj("slot", "n", n)));
        }

        int lx = cx - 150;
        btn("<", lx, rowLook, 22, () -> look(-15, 0));
        btn(">", lx + 24, rowLook, 22, () -> look(15, 0));
        btn("^", lx + 48, rowLook, 22, () -> look(0, -10));
        btn("v", lx + 72, rowLook, 22, () -> look(0, 10));
        btn("Инвентарь", lx + 98, rowLook, 76, () -> client.setScreen(new InvScreen(target, this)));
        btn("Серверден шығу", lx + 176, rowLook, 124, () -> Remote.cmd(target, Remote.obj("leave")));

        btn("Қайта сұрау", cx - 150, rowClose, 100, () -> Remote.request(target));
        btn("Сессияны тоқтату", cx - 48, rowClose, 110, () -> Remote.endSession(target));
        btn("Артқа", cx + 64, rowClose, 86, () -> client.setScreen(new MenuScreen()));
    }

    private void look(double yaw, double pitch) {
        Remote.cmd(target, Remote.obj("look", "dyaw", yaw, "dpitch", pitch));
    }

    private void submit() {
        String t = input.getText().trim();
        if (t.isEmpty()) return;
        input.setText("");
        Session se = s();
        if (t.startsWith(".")) {
            String[] p = t.substring(1).split("\\s+");
            switch (p[0]) {
                case "key" -> { if (p.length > 1) Remote.cmd(target, Remote.obj("tap", "key", p[1], "ticks", p.length > 2 ? parse(p[2]) : 3)); }
                case "hold" -> { if (p.length > 1) Remote.cmd(target, Remote.obj("hold", "key", p[1], "ticks", p.length > 2 ? parse(p[2]) : 20)); }
                case "release" -> { if (p.length > 1) Remote.cmd(target, Remote.obj("release", "key", p[1])); }
                case "ask" -> Remote.request(target);
                default -> se.log("? .key <name> [t] | .hold <name> [t] | .release <name>");
            }
            return;
        }
        se.log("> " + t);
        Remote.cmd(target, Remote.obj("say", "text", t));
    }

    private int parse(String v) { try { return Integer.parseInt(v); } catch (Exception e) { return 3; } }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int cx = width / 2;
        Session se = s();
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Басқару: " + target), cx, 10, 0xFFFFFFFF);
        String st;
        int col = 0xFFFFFFFF;
        switch (se.state) {
            case Session.REQUESTED -> { st = "Рұқсат күтілуде... (ол чатқа .accept жазуы керек)"; col = 0xFFFFFF55; }
            case Session.GRANTED -> { st = "Рұқсат бар"; col = 0xFF55FF55; }
            case Session.REFUSED -> { st = "Бас тартылды " + se.note; col = 0xFFFF5555; }
            default -> { st = "Рұқсат жоқ"; col = 0xFFAAAAAA; }
        }
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(st), cx, 24, col);

        int top = 38;
        if (se.state == Session.GRANTED) {
            JsonObject o = se.status;
            if (o == null || System.currentTimeMillis() - se.statusAt > 5000) {
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Деректер жоқ (байланыс үзілді?)"), cx, top, 0xFFFF5555);
            } else {
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(where(o)), cx, top, 0xFFFFFFFF);
                String scr = o.has("scr") ? "Ашық экран: " + o.get("scr").getAsString() : "Экран жабық";
                if (o.has("hp")) {
                    scr += "   HP " + o.get("hp").getAsInt() + "  Тамақ " + o.get("food").getAsInt()
                            + "  XYZ " + o.get("x").getAsDouble() + " " + o.get("y").getAsDouble() + " " + o.get("z").getAsDouble();
                }
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(scr), cx, top + 12, 0xFFCCCCCC);
                StringBuilder h = new StringBuilder("Басылып тұр: ");
                JsonArray ha = o.getAsJsonArray("held");
                if (ha == null || ha.isEmpty()) h.append("-");
                else for (var e : ha) h.append(e.getAsString()).append(' ');
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(h.toString()), cx, top + 24, 0xFFCCCCCC);
            }
        }

        int logTop = 76, logBottom = height - 142;
        int lines = Math.max(1, (logBottom - logTop) / 10);
        List<String> log = se.last(lines);
        int y = logTop;
        for (String l : log) {
            ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(l, 360), cx - 180, y, 0xFFDDDDDD);
            y += 10;
        }
    }

    static String where(JsonObject o) {
        String w = o.has("w") ? o.get("w").getAsString() : "";
        String d = o.has("d") ? o.get("d").getAsString() : "";
        return switch (w) {
            case "mp" -> "Серверде ойнап жатыр: " + d;
            case "sp" -> "Мирде ойнап жатыр: " + d;
            case "title" -> "Бас менюде тұр";
            case "options" -> "Настройка ашып тұр";
            case "worlds" -> "Мир таңдап тұр";
            case "servers" -> "Сервер тізімін ашып тұр";
            default -> "Басқа экранда тұр";
        };
    }
}
