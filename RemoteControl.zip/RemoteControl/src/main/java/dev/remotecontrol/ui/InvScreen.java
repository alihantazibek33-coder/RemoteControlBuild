package dev.remotecontrol.ui;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.remotecontrol.Remote;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Read-only view of the target's inventory (their screen is not touched). */
public class InvScreen extends Screen {
    private final String target;
    private final Screen parent;

    public InvScreen(String target, Screen parent) {
        super(Text.literal("Inventory " + target));
        this.target = target;
        this.parent = parent;
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("Артқа"), b -> client.setScreen(parent))
                .dimensions(width / 2 - 50, height - 28, 100, 20).build());
    }

    @Override
    public boolean shouldPause() { return false; }

    private static int[] pos(int slot, int ox, int oy) {
        if (slot >= 100 && slot < 104) return new int[]{ox + (slot - 100) * 20, oy};
        if (slot == 150) return new int[]{ox + 5 * 20, oy};
        if (slot < 9) return new int[]{ox + slot * 20, oy + 86};
        int i = slot - 9;
        return new int[]{ox + (i % 9) * 20, oy + 28 + (i / 9) * 20};
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Инвентарь: " + target), cx, 12, 0xFFFFFFFF);
        JsonObject st = Remote.session(target).status;
        if (st == null || !st.has("inv")) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Деректер жоқ (ойыншы әлемде емес)"), cx, 50, 0xFFFF5555);
            return;
        }
        int ox = cx - 90, oy = 34;
        Map<Integer, JsonObject> items = new HashMap<>();
        for (JsonElement e : st.getAsJsonArray("inv")) {
            JsonObject o = e.getAsJsonObject();
            items.put(o.get("s").getAsInt(), o);
        }
        int sel = st.has("slot") ? st.get("slot").getAsInt() : -1;
        int[] all = new int[36 + 5];
        for (int i = 0; i < 36; i++) all[i] = i;
        for (int i = 0; i < 4; i++) all[36 + i] = 100 + i;
        all[40] = 150;
        String hover = null;
        for (int slot : all) {
            int[] p = pos(slot, ox, oy);
            ctx.fill(p[0], p[1], p[0] + 18, p[1] + 18, slot == sel ? 0xFFFFFF55 : 0xFF3C3C3C);
            ctx.fill(p[0] + 1, p[1] + 1, p[0] + 17, p[1] + 17, 0xFF8B8B8B);
            JsonObject it = items.get(slot);
            if (it == null) continue;
            ItemStack stack = new ItemStack(Registries.ITEM.get(Identifier.of(it.get("id").getAsString())), it.get("c").getAsInt());
            ctx.drawItem(stack, p[0] + 1, p[1] + 1);
            ctx.drawStackOverlay(textRenderer, stack, p[0] + 1, p[1] + 1);
            if (mx >= p[0] && mx < p[0] + 18 && my >= p[1] && my < p[1] + 18) {
                hover = it.get("n").getAsString() + " x" + it.get("c").getAsInt();
            }
        }
        if (hover != null) ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(hover), cx, oy + 130, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Жоғарғы қатар: шлем, кеудеше, шалбар, бәтіңке, сол қол"), cx, height - 44, 0xFF888888);
    }
}
