package dev.remotecontrol.ui;

import dev.remotecontrol.Config;
import dev.remotecontrol.Remote;
import dev.remotecontrol.Session;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Locale;

/** Opened with the 0 key: list of players you control + add new nick. */
public class MenuScreen extends Screen {
    private TextFieldWidget nick;
    private String keep = "";

    public MenuScreen() { super(Text.literal("Remote Control")); }

    @Override
    protected void init() {
        int cx = width / 2;
        nick = new TextFieldWidget(textRenderer, cx - 100, 44, 140, 20, Text.literal("Nick"));
        nick.setMaxLength(16);
        nick.setText(keep);
        nick.setPlaceholder(Text.literal("Ник"));
        addDrawableChild(nick);
        addDrawableChild(ButtonWidget.builder(Text.literal("Сұрау"), b -> {
            String n = nick.getText().trim();
            if (n.matches("[A-Za-z0-9_]{1,16}")) { Config.addFriend(n); open(n); }
        }).dimensions(cx + 45, 44, 55, 20).build());

        List<String> f = Config.get().friends;
        for (int i = 0; i < Math.min(f.size(), 8); i++) {
            String n = f.get(i);
            int y = 76 + i * 24;
            addDrawableChild(ButtonWidget.builder(Text.literal(n), b -> open(n))
                    .dimensions(cx - 82, y, 140, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("X"), b -> {
                keep = nick.getText();
                Config.removeFriend(n);
                clearAndInit();
            }).dimensions(cx + 62, y, 20, 20).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Жабу"), b -> close())
                .dimensions(cx - 50, height - 28, 100, 20).build());
    }

    private void open(String n) {
        Session s = Remote.session(n);
        if (s.state != Session.GRANTED) Remote.request(n);
        client.setScreen(new ControlScreen(n));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Remote Control"), cx, 12, 0xFFFFFFFF);
        boolean ok = Remote.RELAY.connected;
        String st = ok ? "Relay: қосылған" : "Relay: қосылмаған " + Remote.RELAY.lastError;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(st), cx, 26, ok ? 0xFF55FF55 : 0xFFFF5555);
        List<String> f = Config.get().friends;
        List<String> on = Remote.online();
        for (int i = 0; i < Math.min(f.size(), 8); i++) {
            int y = 76 + i * 24;
            boolean o = on.contains(f.get(i).toLowerCase(Locale.ROOT));
            ctx.fill(cx - 98, y + 6, cx - 90, y + 14, o ? 0xFF55FF55 : 0xFF777777);
        }
        if (Remote.controller != null) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Сені басқарып жатыр: " + Remote.controller + "  (.stop)"), cx, height - 44, 0xFFFFAA00);
        }
    }
}
