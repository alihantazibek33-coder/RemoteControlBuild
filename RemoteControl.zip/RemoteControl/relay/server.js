// Remote Control relay: dependency-free TCP bridge (Node 16+).
// Run:  RELAY_SECRET=mysecret PORT=25599 node server.js
// Accepts an optional Minecraft handshake packet first (needed for playit "Minecraft Java" tunnels).
const net = require('net');
const { StringDecoder } = require('string_decoder');
const PORT = +process.env.PORT || 25599;
const SECRET = process.env.RELAY_SECRET || '';
const clients = new Map(); // lowercase name -> { name, sock }

const send = (sock, obj) => { try { sock.write(JSON.stringify(obj) + '\n'); } catch (_) {} };

net.createServer(sock => {
  sock.setNoDelay(true); sock.setKeepAlive(true, 30000);
  const dec = new StringDecoder('utf8');
  let raw = Buffer.alloc(0), hs = false, str = '', me = null, count = 0;
  const rl = setInterval(() => { count = 0; }, 1000);
  const timer = setTimeout(() => { if (!me) sock.destroy(); }, 10000);

  const handle = line => {
    let o; try { o = JSON.parse(line); } catch (_) { return; }
    if (++count > 200) return;
    if (!me) {
      if (o.op !== 'hello' || !/^[A-Za-z0-9_]{1,16}$/.test(o.name || '')) return sock.destroy();
      if (SECRET && o.secret !== SECRET) { send(sock, { op: 'err', reason: 'bad_secret' }); return sock.end(); }
      const key = o.name.toLowerCase();
      if (clients.has(key)) { send(sock, { op: 'err', reason: 'name_taken' }); return sock.end(); }
      me = { name: o.name, sock }; clients.set(key, me);
      send(sock, { op: 'hello_ok' });
      return;
    }
    if (o.op === 'who') return send(sock, { op: 'online', names: [...clients.values()].map(c => c.name) });
    if (o.op === 'msg' && typeof o.to === 'string') {
      const t = clients.get(o.to.toLowerCase());
      if (!t) return send(sock, { op: 'err', reason: 'offline', to: o.to });
      const out = { ...o, op: 'msg', from: me.name }; delete out.to;
      send(t.sock, out);
    }
  };

  sock.on('data', d => {
    raw = raw.length ? Buffer.concat([raw, d]) : d;
    if (raw.length > 65536) return sock.destroy();
    if (!hs) {
      if (raw[0] === 0x7b) hs = true; // '{' -> plain JSON, no handshake
      else {
        let len = 0, shift = 0, i = 0, done = false;
        while (i < raw.length && i < 3) { const b = raw[i++]; len |= (b & 0x7f) << shift; shift += 7; if (!(b & 0x80)) { done = true; break; } }
        if (!done) { if (i >= 3) return sock.destroy(); return; }
        if (len > 1024) return sock.destroy();
        if (raw.length < i + len) return;
        raw = raw.subarray(i + len); hs = true;
      }
    }
    if (raw.length) { str += dec.write(raw); raw = Buffer.alloc(0); }
    let i;
    while ((i = str.indexOf('\n')) >= 0) { const l = str.slice(0, i); str = str.slice(i + 1); handle(l); }
  });
  const cleanup = () => {
    clearInterval(rl); clearTimeout(timer);
    if (me && clients.get(me.name.toLowerCase()) === me) clients.delete(me.name.toLowerCase());
  };
  sock.on('close', cleanup); sock.on('error', () => {});
}).listen(PORT, () => console.log('Relay :' + PORT + (SECRET ? ' (secret)' : ' (NO secret!)')));
